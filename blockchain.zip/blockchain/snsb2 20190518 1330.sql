-- MySQL Administrator dump 1.4
--
-- ------------------------------------------------------
-- Server version	5.5.25a


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


--
-- Create schema snsb2
--

CREATE DATABASE IF NOT EXISTS snsb2;
USE snsb2;

--
-- Definition of table `address`
--

DROP TABLE IF EXISTS `address`;
CREATE TABLE `address` (
  `addressId` int(11) NOT NULL AUTO_INCREMENT,
  `addressLine1` varchar(255) DEFAULT NULL,
  `addressLine2` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL,
  `landmark` varchar(255) DEFAULT NULL,
  `pinno` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `street` varchar(255) DEFAULT NULL,
  `userId` int(11) DEFAULT NULL,
  PRIMARY KEY (`addressId`),
  KEY `FK1ED033D4306455CD` (`userId`),
  CONSTRAINT `FK1ED033D4306455CD` FOREIGN KEY (`userId`) REFERENCES `user` (`userId`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `address`
--

/*!40000 ALTER TABLE `address` DISABLE KEYS */;
INSERT INTO `address` (`addressId`,`addressLine1`,`addressLine2`,`city`,`country`,`landmark`,`pinno`,`state`,`street`,`userId`) VALUES 
 (1,'Rawal pada,Dahisar East',NULL,'Mumbai','India','Maharashtra','400068','Maharashtra','S.V Road',1),
 (2,'Room no 4,Chawl no 1,L.K. desai chawl','Rawal pada,Dahisar East','Mumbai','India','Maharashtra','400068','Maharashtra','Room no 4,Chawl no 1,L.K. desai chawl',3),
 (3,'palghar','palghar west','Palghar','India','Dmart','5667786','Maharashtra','S.V Road',4);
/*!40000 ALTER TABLE `address` ENABLE KEYS */;


--
-- Definition of table `beneficiary`
--

DROP TABLE IF EXISTS `beneficiary`;
CREATE TABLE `beneficiary` (
  `beneficiaryId` int(11) NOT NULL AUTO_INCREMENT,
  `accountnumber` varchar(255) DEFAULT NULL,
  `accounttype` varchar(255) DEFAULT NULL,
  `ifsccode` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `userid` int(11) DEFAULT NULL,
  PRIMARY KEY (`beneficiaryId`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `beneficiary`
--

/*!40000 ALTER TABLE `beneficiary` DISABLE KEYS */;
INSERT INTO `beneficiary` (`beneficiaryId`,`accountnumber`,`accounttype`,`ifsccode`,`name`,`status`,`userid`) VALUES 
 (1,'5689334589','SAVING','SNSBK0001','GauravShah','INACTIVE',1),
 (2,'96756756756','SAVING','SNSBK0001','Vipul G','ACTIVE',1),
 (3,'459965656','SAVING','SNSBK0001','Jayesh Thummar','ACTIVE',1),
 (5,'9856789','SAVING','SNSBK0001','Ashwinin','ACTIVE',3);
/*!40000 ALTER TABLE `beneficiary` ENABLE KEYS */;


--
-- Definition of table `beneficiaryactivation`
--

DROP TABLE IF EXISTS `beneficiaryactivation`;
CREATE TABLE `beneficiaryactivation` (
  `beneficiary_id` int(11) NOT NULL,
  `activation_code` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`beneficiary_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `beneficiaryactivation`
--

/*!40000 ALTER TABLE `beneficiaryactivation` DISABLE KEYS */;
INSERT INTO `beneficiaryactivation` (`beneficiary_id`,`activation_code`) VALUES 
 (2,'869382'),
 (3,'928302'),
 (4,'864252'),
 (5,'490687');
/*!40000 ALTER TABLE `beneficiaryactivation` ENABLE KEYS */;


--
-- Definition of table `branch`
--

DROP TABLE IF EXISTS `branch`;
CREATE TABLE `branch` (
  `branchId` int(11) NOT NULL AUTO_INCREMENT,
  `addressline1` varchar(255) DEFAULT NULL,
  `addressline2` varchar(255) DEFAULT NULL,
  `branchname` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL,
  `ifsccode` varchar(255) DEFAULT NULL,
  `landmark` varchar(255) DEFAULT NULL,
  `pinno` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `street` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`branchId`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `branch`
--

/*!40000 ALTER TABLE `branch` DISABLE KEYS */;
INSERT INTO `branch` (`branchId`,`addressline1`,`addressline2`,`branchname`,`city`,`country`,`ifsccode`,`landmark`,`pinno`,`state`,`street`) VALUES 
 (1,'Kasturba Road','Kamla Vihar ','Borivali East','Mumbai','India','SNSB2K0001','Chamunda Circle','400068','Maharashtra','M.G Road'),
 (2,'Thakur Complex','Nivas Kunj','Thakur Complex','Mumbai','India','SNSB2K0001','Sai Dham Temple','400088','Maharashtra','Near Western Express Highway');
/*!40000 ALTER TABLE `branch` ENABLE KEYS */;


--
-- Definition of table `country`
--

DROP TABLE IF EXISTS `country`;
CREATE TABLE `country` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `country`
--

/*!40000 ALTER TABLE `country` DISABLE KEYS */;
INSERT INTO `country` (`id`,`name`) VALUES 
 (1,'India'),
 (2,'Australia');
/*!40000 ALTER TABLE `country` ENABLE KEYS */;


--
-- Definition of table `countrystate`
--

DROP TABLE IF EXISTS `countrystate`;
CREATE TABLE `countrystate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `countryname` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `countrystate`
--

/*!40000 ALTER TABLE `countrystate` DISABLE KEYS */;
INSERT INTO `countrystate` (`id`,`name`,`countryname`) VALUES 
 (1,'Maharashtra','India'),
 (2,'Gujarat','India'),
 (3,'Karnataka','India'),
 (4,'Sydney','Australia'),
 (5,'Perth','Australia');
/*!40000 ALTER TABLE `countrystate` ENABLE KEYS */;


--
-- Definition of table `forget_password_verification`
--

DROP TABLE IF EXISTS `forget_password_verification`;
CREATE TABLE `forget_password_verification` (
  `userId` int(11) NOT NULL,
  `verificationtoken` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `forget_password_verification`
--

/*!40000 ALTER TABLE `forget_password_verification` DISABLE KEYS */;
/*!40000 ALTER TABLE `forget_password_verification` ENABLE KEYS */;


--
-- Definition of table `otpgeneration`
--

DROP TABLE IF EXISTS `otpgeneration`;
CREATE TABLE `otpgeneration` (
  `userId` int(11) NOT NULL,
  `generatedDate` datetime DEFAULT NULL,
  `otp` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `otpgeneration`
--

/*!40000 ALTER TABLE `otpgeneration` DISABLE KEYS */;
INSERT INTO `otpgeneration` (`userId`,`generatedDate`,`otp`) VALUES 
 (1,'2016-05-07 15:12:43','215388');
/*!40000 ALTER TABLE `otpgeneration` ENABLE KEYS */;


--
-- Definition of table `role`
--

DROP TABLE IF EXISTS `role`;
CREATE TABLE `role` (
  `roleId` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`roleId`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `role`
--

/*!40000 ALTER TABLE `role` DISABLE KEYS */;
INSERT INTO `role` (`roleId`,`description`,`name`) VALUES 
 (1,'ADMIN','ROLE_ADMIN'),
 (2,'USER','ROLE_USER');
/*!40000 ALTER TABLE `role` ENABLE KEYS */;


--
-- Definition of table `servicerequest`
--

DROP TABLE IF EXISTS `servicerequest`;
CREATE TABLE `servicerequest` (
  `requestId` int(11) NOT NULL AUTO_INCREMENT,
  `createdby` int(11) DEFAULT NULL,
  `deliveryDate` datetime DEFAULT NULL,
  `requestDate` datetime DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `servicename` varchar(255) NOT NULL,
  PRIMARY KEY (`requestId`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `servicerequest`
--

/*!40000 ALTER TABLE `servicerequest` DISABLE KEYS */;
INSERT INTO `servicerequest` (`requestId`,`createdby`,`deliveryDate`,`requestDate`,`status`,`servicename`) VALUES 
 (1,1,'2016-05-05 19:35:17','2016-02-19 20:09:12','COMPLETED','CREDIT CARD'),
 (2,1,'2016-05-07 15:16:12','2016-02-20 15:56:14','COMPLETED','CREDIT CARD'),
 (3,4,NULL,'2016-05-07 15:25:49','IN PROGRESS','ATM CUM DEBIT CARD');
/*!40000 ALTER TABLE `servicerequest` ENABLE KEYS */;


--
-- Definition of table `servicetype`
--

DROP TABLE IF EXISTS `servicetype`;
CREATE TABLE `servicetype` (
  `serviceId` int(11) NOT NULL AUTO_INCREMENT,
  `servicename` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`serviceId`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `servicetype`
--

/*!40000 ALTER TABLE `servicetype` DISABLE KEYS */;
INSERT INTO `servicetype` (`serviceId`,`servicename`) VALUES 
 (1,'ATM CUM DEBIT CARD'),
 (2,'CREDIT CARD'),
 (3,'CHEQUE BOOK REQUEST'),
 (4,'NEW PASSBOOK REQUEST'),
 (5,'PERSONAL LOAN ENQUIRY');
/*!40000 ALTER TABLE `servicetype` ENABLE KEYS */;


--
-- Definition of table `transaction`
--

DROP TABLE IF EXISTS `transaction`;
CREATE TABLE `transaction` (
  `transactionId` int(11) NOT NULL AUTO_INCREMENT,
  `accountId` int(11) DEFAULT NULL,
  `operation` varchar(255) DEFAULT NULL,
  `transactionDate` datetime DEFAULT NULL,
  `transferamount` bigint(20) DEFAULT NULL,
  `userId` int(11) DEFAULT NULL,
  `benificiaryId` int(11) DEFAULT NULL,
  `transferId` int(11) DEFAULT NULL,
  PRIMARY KEY (`transactionId`),
  KEY `FK7FA0D2DE9C3A92C5` (`benificiaryId`),
  KEY `FK7FA0D2DEA0F1210E` (`transferId`),
  CONSTRAINT `FK7FA0D2DE9C3A92C5` FOREIGN KEY (`benificiaryId`) REFERENCES `beneficiary` (`beneficiaryId`),
  CONSTRAINT `FK7FA0D2DEA0F1210E` FOREIGN KEY (`transferId`) REFERENCES `transferrequest` (`transferId`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `transaction`
--

/*!40000 ALTER TABLE `transaction` DISABLE KEYS */;
INSERT INTO `transaction` (`transactionId`,`accountId`,`operation`,`transactionDate`,`transferamount`,`userId`,`benificiaryId`,`transferId`) VALUES 
 (1,1,'DEBIT','2016-02-19 00:21:43',6000,1,2,NULL),
 (2,1,'DEBIT','2016-02-20 15:55:21',1200,1,2,NULL),
 (3,1,'DEBIT','2016-05-07 15:13:48',100,1,2,NULL),
 (4,1,'DEBIT','2018-03-12 18:01:09',1000,1,2,NULL);
/*!40000 ALTER TABLE `transaction` ENABLE KEYS */;


--
-- Definition of table `transferrequest`
--

DROP TABLE IF EXISTS `transferrequest`;
CREATE TABLE `transferrequest` (
  `transferId` int(11) NOT NULL AUTO_INCREMENT,
  `accountNumber` varchar(255) DEFAULT NULL,
  `receivedDate` datetime DEFAULT NULL,
  `sender_account_number` varchar(255) DEFAULT NULL,
  `senderName` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `transferDate` datetime DEFAULT NULL,
  PRIMARY KEY (`transferId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `transferrequest`
--

/*!40000 ALTER TABLE `transferrequest` DISABLE KEYS */;
/*!40000 ALTER TABLE `transferrequest` ENABLE KEYS */;


--
-- Definition of table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `userId` int(11) NOT NULL AUTO_INCREMENT,
  `contactnumber` varchar(255) DEFAULT NULL,
  `creationDate` datetime DEFAULT NULL,
  `dob` datetime DEFAULT NULL,
  `emailId` varchar(255) DEFAULT NULL,
  `firstname` varchar(255) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `isEnabled` tinyint(1) DEFAULT NULL,
  `isLocked` tinyint(1) DEFAULT NULL,
  `lastLogin` datetime DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `no_of_attempt` int(11) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `passwordDate` datetime DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `transactionPassword` varchar(255) DEFAULT NULL,
  `transactionPasswordDate` datetime DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `branchId` int(11) NOT NULL,
  `roleId` int(11) NOT NULL,
  PRIMARY KEY (`userId`),
  KEY `FK36EBCB2B0F0063` (`roleId`),
  KEY `FK36EBCB967F28BB` (`branchId`),
  CONSTRAINT `FK36EBCB2B0F0063` FOREIGN KEY (`roleId`) REFERENCES `role` (`roleId`),
  CONSTRAINT `FK36EBCB967F28BB` FOREIGN KEY (`branchId`) REFERENCES `branch` (`branchId`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` (`userId`,`contactnumber`,`creationDate`,`dob`,`emailId`,`firstname`,`gender`,`isEnabled`,`isLocked`,`lastLogin`,`lastName`,`no_of_attempt`,`password`,`passwordDate`,`status`,`transactionPassword`,`transactionPasswordDate`,`username`,`branchId`,`roleId`) VALUES 
 (1,'+919773523004',NULL,'1991-02-09 00:00:00','mehulxie@gmail.com','Mehul','MALE',1,0,NULL,'Ghodasara',0,'1234',NULL,'ACTIVE','377662',NULL,'mehul',1,2),
 (2,'+919773523004',NULL,'1991-02-09 00:00:00','mehulxie@gmail.com','Kaiz','MALE',1,0,NULL,'Rozani',0,'1234',NULL,'ACTIVE','1234',NULL,'kaiz',1,1),
 (3,'9773523004','2016-03-06 00:25:50','2016-07-07 00:00:00','mehulxie@gmail.com','Mehul','MALE',1,0,NULL,'Ghodasara',NULL,'925708',NULL,'ACTIVE','733333',NULL,'3180926',1,2),
 (4,'9833623457','2016-05-07 15:22:32','1995-10-09 00:00:00','pooja8@gmail.com','Pooja','Female',1,0,NULL,'Varkhande',NULL,'150556',NULL,'ACTIVE','150556',NULL,'4180927',1,2);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;


--
-- Definition of table `useraccount`
--

DROP TABLE IF EXISTS `useraccount`;
CREATE TABLE `useraccount` (
  `accountId` int(11) NOT NULL AUTO_INCREMENT,
  `accountnumber` varchar(255) DEFAULT NULL,
  `accounttype` varchar(255) DEFAULT NULL,
  `balance` bigint(20) DEFAULT NULL,
  `creationDate` datetime DEFAULT NULL,
  `interestrate` float DEFAULT NULL,
  `userId` int(11) DEFAULT NULL,
  PRIMARY KEY (`accountId`),
  KEY `FK449CD402306455CD` (`userId`),
  CONSTRAINT `FK449CD402306455CD` FOREIGN KEY (`userId`) REFERENCES `user` (`userId`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `useraccount`
--

/*!40000 ALTER TABLE `useraccount` DISABLE KEYS */;
INSERT INTO `useraccount` (`accountId`,`accountnumber`,`accounttype`,`balance`,`creationDate`,`interestrate`,`userId`) VALUES 
 (1,'180925','SAVING',21700,'2016-01-25 23:15:03',10.25,1),
 (2,'180926','SAVING',2300,'2016-03-06 00:03:37',10.25,3),
 (3,'180927','SAVING',0,'2016-05-07 15:20:37',10.25,4);
/*!40000 ALTER TABLE `useraccount` ENABLE KEYS */;




/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
